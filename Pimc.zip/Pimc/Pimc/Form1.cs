﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso;
        double altura;
        double imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxpeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnsair)
            {
                return;
            }

            if (!double.TryParse(mskbxpeso.Text, out peso))
            {
                MessageBox.Show("Peso invalido");
                mskbxpeso.Focus();
            }
            else
            {
                if (peso <= 0)
                {
                    MessageBox.Show("Peso invalido");
                    mskbxpeso.Focus();
                }
            }
        }

        private void mskbxaltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnsair)
            {
                return;
            }

            if (!double.TryParse(mskbxaltura.Text, out altura))
            {
                MessageBox.Show("Altura invalida");
                mskbxaltura.Focus();
            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Altura invalida");
                    mskbxaltura.Focus();
                }
            }
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            imc = Math.Round(imc, 2);
            txtimcvalor.Text = imc.ToString("N2");
            if (imc <= 18.5)
            {
                txtimc.Text = imc.ToString("MAGREZA");
            }
            else
            {
                if (imc <= 24.9)
                {
                    txtimc.Text = imc.ToString("NORMAL");
                }
                else
                {
                    if (imc <= 29.9)
                    {
                        txtimc.Text = imc.ToString("SOBREPESO");
                    }
                    else
                    {
                        if (imc <= 39.9)
                        {
                            txtimc.Text = imc.ToString("OBESIDADE");
                        }
                        else
                        {
                            if (imc > 40)
                            {
                                txtimc.Text = imc.ToString("OBESIDADE GRAVE");
                            }
                        }
                    }
                }
            }

        }

        private void btnlimp_Click(object sender, EventArgs e)
        {
            txtimc.Clear();
            mskbxaltura.Clear();
            mskbxpeso.Clear();
        }
    }
}
