﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[2, 4];
            string aux = "";
            double[] totalmes = new double[2];
            double totalGeral = 0;
            
            

            for (int mes = 0; mes < 2; mes++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    aux = Interaction.InputBox($"Total Vendido da semana " + [semana] + " no mes " + (mes + 1) + ":");

                    if (aux == "")
                        return;
                    if (!double.TryParse(aux, out valores[mes, semana]) || valores[mes, semana] <= 0)
                    {
                        MessageBox.Show("Valor invalido");
                        semana--;
                    }
                    else
                    {
                        totalmes[mes] += valores[mes, semana];
                    }
                }
               double totalGeral[mes] += totalmes[mes];

            }
            double totalGeral1 = 0;
            for (int mes = 0; mes < 2; mes++)
            {
                lstxbvalores.Items.Add($"Total do mes: {totalGeral[mes]} Semana {semana}:C2");
                totalGeral1 += totalmes[mes];
            }
            lstxbvalores.Items.Add("------------------------------");
            lstxbvalores.Items.Add($"total geral : {totalGeral1:C2} ->  {totalGeral1:C2}");
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            lstxbvalores.Items.Clear();
        }
    }
    }

