﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumero_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            int N;
            double H = 0;
            if (!int.TryParse(txtNumero.Text, out N) || N <= 0)
            {
                MessageBox.Show("Numero Inválido");
                txtNumero.Focus();
            }
            else
            {
                for (int i = 1; i <= N; i++)
                {
                    H =(double) H + (1.0 / i);
                }
                MessageBox.Show($"O valor de H = {H:F2} ");
            }
            
        }
    }
}
