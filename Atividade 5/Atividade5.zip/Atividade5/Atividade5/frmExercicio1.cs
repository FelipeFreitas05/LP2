﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int contaEspaco = -1;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    contaEspaco++;
                }
            }

            MessageBox.Show($"A frase tem {contaEspaco} Espaços");
        }

        private void qtdeR_Click(object sender, EventArgs e)
        {
            int contaR = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.ToLower(c) =='r')
                {
                    contaR++;
                }
            }

            MessageBox.Show($"A frase tem {contaR} R");
        }

        private void btnMesmoPar_Click(object sender, EventArgs e)
        {
            char previousChar = '\0';
            int Duplicado = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (c == previousChar)
                {
                    Duplicado++;
                }
                previousChar = c; // Update for the next iteration
            }
          

            MessageBox.Show($"A frase tem {Duplicado} pares de letras");
        }
    }
    
}
