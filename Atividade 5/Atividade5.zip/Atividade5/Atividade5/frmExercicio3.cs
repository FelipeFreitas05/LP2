﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            if(txtFrase.Text.Length>50)
            {
                MessageBox.Show("A frase ultrapassa 50 caracteres!");
                txtFrase.Clear();
                txtFrase.Focus();
            }
            else if(txtFrase.Text.Length == 0)
            {
                MessageBox.Show("Digite uma frase com até 50 caracteres");
                txtFrase.Focus();
            }
            else
            {
                string Frase=txtFrase.Text;
                string FraseOriginal=txtFrase.Text;
                string FraseInvertida = "";
                
                Frase = Frase.Replace(" ", "");
                Frase = Frase.ToUpper();

                char[] VetorFrase = Frase.ToCharArray();
                Array.Reverse(VetorFrase);
                for (int i = Frase.Length - 1; i >= 0; i--)
                {
                    FraseInvertida += Frase[i];
                }

                if(string.Compare(FraseInvertida,Frase)==0)
                {
                    MessageBox.Show($"A frase {FraseOriginal} é um Palindromo");
                }
                else
                {
                    MessageBox.Show($"A frase {FraseOriginal} não é um Palindromo");
                }

            }
        }
    }
}
