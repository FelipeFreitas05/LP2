﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalBruto_Click(object sender, EventArgs e)
        {
            double A, producao, gratificacoes, salarioBruto;
            int B = 0, C = 0, D = 0;

            if (!double.TryParse(mskbxSalario.Text, out A) || A <= 0)
            {
                MessageBox.Show("Salário Base Inválido");
                mskbxSalario.Focus();
                return;
            }

            if (!double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Produção Inválida");
                txtProducao.Focus();
                return;
            }

            if (!double.TryParse(txtGratificacao.Text, out gratificacoes))
            {
                gratificacoes = 0;
            }

            if(producao<120)
            {
                B = 1;
            }
            else if(producao<150)
            {
                B = 1;
                C = 1;
            }
            else if(producao>=150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacoes;

            if (salarioBruto > 7000 && producao < 150 && gratificacoes == 0)
            {
                salarioBruto = 7000;
                MessageBox.Show("Voce não atingiu todos os requisitos, por isso salario = R$7.000,00");
            }

            MessageBox.Show($"Salario bruto é de {salarioBruto:C2}");

        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSalBruto)
            {
                return;
            }
            string Nome = txtNome.Text;
            if (txtNome.Text == null)
            {
                MessageBox.Show("Digite um nome");
                txtNome.Focus();
            }
            if (Nome.Any(char.IsDigit)||Nome.Any(char.IsPunctuation))
            {
                MessageBox.Show("Nome nao pode conter números nem caracteres especiais");
                txtNome.Focus();
            }
        }

        private void txtMatricula_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSalBruto)
            {
                return;
            }
            int matricula = 0;

            if (!int.TryParse(txtMatricula.Text, out matricula)||matricula<0)
            {
                MessageBox.Show("Matricula Invalida");
                txtMatricula.Focus();
            }
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSalBruto)
            {
                return;
            }
            int producao = 0;

            if (!int.TryParse(txtProducao.Text, out producao)||producao<0)
            {
                MessageBox.Show("Producao Invalida");
                txtProducao.Focus();
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSalBruto)
            {
                return;
            }
            int gratificacao = 0;

            if (!int.TryParse(txtGratificacao.Text, out gratificacao) || gratificacao < 0)
            {
                MessageBox.Show("gratificacao Invalida");
                txtGratificacao.Focus();
            }
        }
    }
}
