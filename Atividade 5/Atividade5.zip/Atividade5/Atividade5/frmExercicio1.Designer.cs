﻿namespace Atividade5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.qtdeR = new System.Windows.Forms.Button();
            this.btnMesmoPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(68, 55);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(300, 286);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(457, 55);
            this.btnEspacoBranco.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(200, 64);
            this.btnEspacoBranco.TabIndex = 1;
            this.btnEspacoBranco.Text = "Nº ESPACO BRANCO";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // qtdeR
            // 
            this.qtdeR.Location = new System.Drawing.Point(457, 169);
            this.qtdeR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.qtdeR.Name = "qtdeR";
            this.qtdeR.Size = new System.Drawing.Size(200, 64);
            this.qtdeR.TabIndex = 2;
            this.qtdeR.Text = "Quantos \"R\"";
            this.qtdeR.UseVisualStyleBackColor = true;
            this.qtdeR.Click += new System.EventHandler(this.qtdeR_Click);
            // 
            // btnMesmoPar
            // 
            this.btnMesmoPar.Location = new System.Drawing.Point(457, 277);
            this.btnMesmoPar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMesmoPar.Name = "btnMesmoPar";
            this.btnMesmoPar.Size = new System.Drawing.Size(200, 64);
            this.btnMesmoPar.TabIndex = 3;
            this.btnMesmoPar.Text = "Mesmo Par";
            this.btnMesmoPar.UseVisualStyleBackColor = true;
            this.btnMesmoPar.Click += new System.EventHandler(this.btnMesmoPar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(777, 418);
            this.Controls.Add(this.btnMesmoPar);
            this.Controls.Add(this.qtdeR);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmExercicio1";
            this.Text = "FrmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button qtdeR;
        private System.Windows.Forms.Button btnMesmoPar;
    }
}