﻿namespace Atividade6
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exc1 = new System.Windows.Forms.Button();
            this.btn_Exc2 = new System.Windows.Forms.Button();
            this.btn_Exc3 = new System.Windows.Forms.Button();
            this.btn_Exc4 = new System.Windows.Forms.Button();
            this.btn_Exc5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Exc1
            // 
            this.btn_Exc1.BackColor = System.Drawing.Color.DeepPink;
            this.btn_Exc1.Location = new System.Drawing.Point(213, 37);
            this.btn_Exc1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exc1.Name = "btn_Exc1";
            this.btn_Exc1.Size = new System.Drawing.Size(264, 151);
            this.btn_Exc1.TabIndex = 0;
            this.btn_Exc1.Text = "Exercício 1";
            this.btn_Exc1.UseVisualStyleBackColor = false;
            this.btn_Exc1.Click += new System.EventHandler(this.btn_Exc1_Click);
            // 
            // btn_Exc2
            // 
            this.btn_Exc2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Exc2.Location = new System.Drawing.Point(612, 37);
            this.btn_Exc2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exc2.Name = "btn_Exc2";
            this.btn_Exc2.Size = new System.Drawing.Size(264, 151);
            this.btn_Exc2.TabIndex = 1;
            this.btn_Exc2.Text = "Exercício 2";
            this.btn_Exc2.UseVisualStyleBackColor = false;
            this.btn_Exc2.Click += new System.EventHandler(this.btn_Exc2_Click);
            // 
            // btn_Exc3
            // 
            this.btn_Exc3.BackColor = System.Drawing.Color.Blue;
            this.btn_Exc3.Location = new System.Drawing.Point(213, 231);
            this.btn_Exc3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exc3.Name = "btn_Exc3";
            this.btn_Exc3.Size = new System.Drawing.Size(264, 151);
            this.btn_Exc3.TabIndex = 2;
            this.btn_Exc3.Text = "Exercício 3";
            this.btn_Exc3.UseVisualStyleBackColor = false;
            this.btn_Exc3.Click += new System.EventHandler(this.btn_Exc3_Click);
            // 
            // btn_Exc4
            // 
            this.btn_Exc4.BackColor = System.Drawing.Color.Green;
            this.btn_Exc4.Location = new System.Drawing.Point(612, 231);
            this.btn_Exc4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exc4.Name = "btn_Exc4";
            this.btn_Exc4.Size = new System.Drawing.Size(264, 151);
            this.btn_Exc4.TabIndex = 3;
            this.btn_Exc4.Text = "Exercício 4";
            this.btn_Exc4.UseVisualStyleBackColor = false;
            this.btn_Exc4.Click += new System.EventHandler(this.btn_Exc4_Click);
            // 
            // btn_Exc5
            // 
            this.btn_Exc5.BackColor = System.Drawing.Color.Yellow;
            this.btn_Exc5.Location = new System.Drawing.Point(415, 390);
            this.btn_Exc5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exc5.Name = "btn_Exc5";
            this.btn_Exc5.Size = new System.Drawing.Size(264, 151);
            this.btn_Exc5.TabIndex = 4;
            this.btn_Exc5.Text = "Exercício 5";
            this.btn_Exc5.UseVisualStyleBackColor = false;
            this.btn_Exc5.Click += new System.EventHandler(this.btn_Exc5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btn_Exc5);
            this.Controls.Add(this.btn_Exc4);
            this.Controls.Add(this.btn_Exc3);
            this.Controls.Add(this.btn_Exc2);
            this.Controls.Add(this.btn_Exc1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Exc1;
        private System.Windows.Forms.Button btn_Exc2;
        private System.Windows.Forms.Button btn_Exc3;
        private System.Windows.Forms.Button btn_Exc4;
        private System.Windows.Forms.Button btn_Exc5;
    }
}

