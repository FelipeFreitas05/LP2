﻿namespace Atividade6
{
    partial class frm_Exc3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Executar = new System.Windows.Forms.Button();
            this.lst_Verificador = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_Executar
            // 
            this.btn_Executar.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btn_Executar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Executar.Location = new System.Drawing.Point(119, 190);
            this.btn_Executar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Executar.Name = "btn_Executar";
            this.btn_Executar.Size = new System.Drawing.Size(323, 153);
            this.btn_Executar.TabIndex = 0;
            this.btn_Executar.Text = "Executar";
            this.btn_Executar.UseVisualStyleBackColor = false;
            this.btn_Executar.Click += new System.EventHandler(this.btn_Executar_Click);
            // 
            // lst_Verificador
            // 
            this.lst_Verificador.BackColor = System.Drawing.SystemColors.Highlight;
            this.lst_Verificador.FormattingEnabled = true;
            this.lst_Verificador.ItemHeight = 16;
            this.lst_Verificador.Location = new System.Drawing.Point(527, 81);
            this.lst_Verificador.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lst_Verificador.Name = "lst_Verificador";
            this.lst_Verificador.Size = new System.Drawing.Size(408, 372);
            this.lst_Verificador.TabIndex = 1;
            // 
            // frm_Exc3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lst_Verificador);
            this.Controls.Add(this.btn_Executar);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frm_Exc3";
            this.Text = "frm_Exc3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Executar;
        private System.Windows.Forms.ListBox lst_Verificador;
    }
}