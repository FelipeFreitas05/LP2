﻿namespace Ptestemetodo
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btncontanumero = new System.Windows.Forms.Button();
            this.btncaracterbranco = new System.Windows.Forms.Button();
            this.btncontaletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(152, 159);
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(480, 163);
            this.rchtxtfrase.TabIndex = 0;
            this.rchtxtfrase.Text = "";
            // 
            // btncontanumero
            // 
            this.btncontanumero.BackColor = System.Drawing.Color.GreenYellow;
            this.btncontanumero.Location = new System.Drawing.Point(12, 12);
            this.btncontanumero.Name = "btncontanumero";
            this.btncontanumero.Size = new System.Drawing.Size(603, 101);
            this.btncontanumero.TabIndex = 1;
            this.btncontanumero.Text = "Conta Numero";
            this.btncontanumero.UseVisualStyleBackColor = false;
            this.btncontanumero.Click += new System.EventHandler(this.btncontanumero_Click);
            // 
            // btncaracterbranco
            // 
            this.btncaracterbranco.BackColor = System.Drawing.Color.Red;
            this.btncaracterbranco.Location = new System.Drawing.Point(12, 397);
            this.btncaracterbranco.Name = "btncaracterbranco";
            this.btncaracterbranco.Size = new System.Drawing.Size(444, 41);
            this.btncaracterbranco.TabIndex = 2;
            this.btncaracterbranco.Text = "localiza primeiro caracter em branco";
            this.btncaracterbranco.UseVisualStyleBackColor = false;
            this.btncaracterbranco.Click += new System.EventHandler(this.btncaracterbranco_Click);
            // 
            // btncontaletras
            // 
            this.btncontaletras.BackColor = System.Drawing.Color.DeepPink;
            this.btncontaletras.Location = new System.Drawing.Point(713, 61);
            this.btncontaletras.Name = "btncontaletras";
            this.btncontaletras.Size = new System.Drawing.Size(75, 357);
            this.btncontaletras.TabIndex = 3;
            this.btncontaletras.Text = "conta letras";
            this.btncontaletras.UseVisualStyleBackColor = false;
            this.btncontaletras.Click += new System.EventHandler(this.btncontaletras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btncontaletras);
            this.Controls.Add(this.btncaracterbranco);
            this.Controls.Add(this.btncontanumero);
            this.Controls.Add(this.rchtxtfrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtfrase;
        private System.Windows.Forms.Button btncontanumero;
        private System.Windows.Forms.Button btncaracterbranco;
        private System.Windows.Forms.Button btncontaletras;
    }
}