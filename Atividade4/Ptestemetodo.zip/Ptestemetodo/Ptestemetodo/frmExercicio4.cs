﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodo
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btncontanumero_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contador = 0;
            int contnum = 0;

            while (contador < rchtxtfrase.Text.Length)
            {
                if (char.IsNumber(rchtxtfrase.Text[contador]))
                {
                    contnum++;
                }
                contador++;
            }
            MessageBox.Show("a frase tem" + contnum+ " numeros");
        }

        private void btncaracterbranco_Click(object sender, EventArgs e)
        {
            int posicao = -1;
            for (int i = 0; i < rchtxtfrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtfrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            if (posicao > 0)
                MessageBox.Show("1° caracter em branco esta na posição " + posicao);
            else
                MessageBox.Show("nao ha espaços em branco");
        }

        private void btncontaletras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach(char c in rchtxtfrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"a frase tem {contaLetra} Letras");
        }
    }
}
