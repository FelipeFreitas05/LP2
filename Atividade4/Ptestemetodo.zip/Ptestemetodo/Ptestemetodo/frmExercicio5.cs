﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodo
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnsortar_Click(object sender, EventArgs e)
        {
            int numero1, numero2;
            if (!int.TryParse(txtnumero1.Text, out numero1) || (numero1 < 0))
            {
                MessageBox.Show("N° 1 Invalido!");
                txtnumero1.Focus();
            }

            else if (!int.TryParse(txtnumero2.Text, out numero2) || (numero2 < 0))
            {
                MessageBox.Show("N° 2 Invalido");
                txtnumero2.Focus();
            }
                
                    else if (numero1 > numero2)
                    {
                      MessageBox.Show("N°1 é maior que o N° 2");
                      txtnumero1.Focus();
                    }
                        
                        
                            else
                            {
                              Random OBJR = new Random();
                              int sorteado = OBJR.Next(numero1, numero2);
                              MessageBox.Show(sorteado.ToString());
                            }




        }
    }
}

