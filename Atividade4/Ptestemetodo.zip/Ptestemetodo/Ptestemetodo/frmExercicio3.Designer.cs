﻿namespace Ptestemetodo
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.btnremover = new System.Windows.Forms.Button();
            this.Btninverter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(395, 76);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(64, 16);
            this.lblpalavra2.TabIndex = 10;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(100, 75);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(64, 16);
            this.lblpalavra1.TabIndex = 9;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(479, 70);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(184, 22);
            this.txtpalavra2.TabIndex = 8;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(171, 70);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(159, 22);
            this.txtpalavra1.TabIndex = 7;
            // 
            // btnremover
            // 
            this.btnremover.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnremover.Location = new System.Drawing.Point(89, 225);
            this.btnremover.Name = "btnremover";
            this.btnremover.Size = new System.Drawing.Size(429, 213);
            this.btnremover.TabIndex = 11;
            this.btnremover.Text = "Remover ocorrencias do 1 no segundo";
            this.btnremover.UseVisualStyleBackColor = false;
            this.btnremover.Click += new System.EventHandler(this.btnremover_Click);
            // 
            // Btninverter
            // 
            this.Btninverter.BackColor = System.Drawing.Color.LimeGreen;
            this.Btninverter.Location = new System.Drawing.Point(601, 98);
            this.Btninverter.Name = "Btninverter";
            this.Btninverter.Size = new System.Drawing.Size(62, 340);
            this.Btninverter.TabIndex = 12;
            this.Btninverter.Text = "inverter";
            this.Btninverter.UseVisualStyleBackColor = false;
            this.Btninverter.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btninverter);
            this.Controls.Add(this.btnremover);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Button btnremover;
        private System.Windows.Forms.Button Btninverter;
    }
}