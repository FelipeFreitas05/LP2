﻿namespace Ptestemetodo
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btncomparar = new System.Windows.Forms.Button();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(201, 80);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(159, 22);
            this.txtpalavra1.TabIndex = 0;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(509, 80);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(184, 22);
            this.txtpalavra2.TabIndex = 1;
            // 
            // btncomparar
            // 
            this.btncomparar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btncomparar.Location = new System.Drawing.Point(201, 218);
            this.btncomparar.Name = "btncomparar";
            this.btncomparar.Size = new System.Drawing.Size(75, 195);
            this.btncomparar.TabIndex = 2;
            this.btncomparar.Text = "Comparar";
            this.btncomparar.UseVisualStyleBackColor = false;
            this.btncomparar.Click += new System.EventHandler(this.btncomparar_Click);
            // 
            // btninserir1
            // 
            this.btninserir1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btninserir1.Location = new System.Drawing.Point(352, 218);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(75, 195);
            this.btninserir1.TabIndex = 3;
            this.btninserir1.Text = "Inserir 1";
            this.btninserir1.UseVisualStyleBackColor = false;
            this.btninserir1.Click += new System.EventHandler(this.btninserir1_Click);
            // 
            // btninserir2
            // 
            this.btninserir2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btninserir2.Location = new System.Drawing.Point(509, 218);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(75, 195);
            this.btninserir2.TabIndex = 4;
            this.btninserir2.Text = "Inserir 2";
            this.btninserir2.UseVisualStyleBackColor = false;
            this.btninserir2.Click += new System.EventHandler(this.btninserir2_Click);
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(130, 85);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(64, 16);
            this.lblpalavra1.TabIndex = 5;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(425, 86);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(64, 16);
            this.lblpalavra2.TabIndex = 6;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.btncomparar);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.Load += new System.EventHandler(this.frmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btncomparar;
        private System.Windows.Forms.Button btninserir1;
        private System.Windows.Forms.Button btninserir2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
    }
}