﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodo
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void btncomparar_Click(object sender, EventArgs e)
        {
            string Palavra1;
            string Palavra2;

            if (String.Compare(txtpalavra1.Text, txtpalavra2.Text, true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void btninserir1_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra2.TextLength / 2;
            txtpalavra2.Text=  txtpalavra2.Text.Substring(0, meio)+ txtpalavra1.Text 
                + txtpalavra2.Text.Substring(meio, txtpalavra2.Text.Length - meio);
        }

        private void btninserir2_Click(object sender, EventArgs e)
        {
            int meio2 = txtpalavra1.TextLength / 2;
            txtpalavra1.Text = txtpalavra1.Text.Insert(meio2, "**");
        }
    }
}
